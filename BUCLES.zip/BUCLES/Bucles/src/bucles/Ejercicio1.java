package bucles;
import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		/* Diseñar un programa para aprender a contar. El programa 
		 * pedirá un número y mostrará todos los números comprendidos 
		 * entre el 1 y el número introducido.
		 * Cuestiones para que pase los test:
		 * Para pedir el número debe mostrar el mensaje exacto 
		 * "Introduzca un número:"
		 * 
		 */
		
		// Variables
			int num, contador;
			Scanner teclado = new Scanner(System.in);
		// Inicio
			contador=1;
			
			System.out.println("Introduzca un número:");
			num=Integer.parseInt(teclado.nextLine());
			
			while (contador<=num){
				System.out.println(contador);
				contador=contador+1;
			}
	}

}
