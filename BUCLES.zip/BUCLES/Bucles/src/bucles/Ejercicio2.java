package bucles;
import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		/* Diseñar un programa que pida dos números. Deberá ver cuál de 
		 * ellos es menor y mostrar todos los números comprendidos entre 
		 * el valor menor y mayor, incluyendo ambos números.
		 * Cuestiones para que pase los test:
		 * Para pedir el número debe mostrar el mensaje exacto 
		 * "Introduzca un número:"
		 * Luego "Introduzca el segundo número:"
		 */
		
		// Variables
			int num1, num2, vi, vf, i;
			Scanner teclado = new Scanner(System.in);
		// Inicio
			System.out.println("Introduzca un número:");
			num1=Integer.parseInt(teclado.nextLine());
			System.out.println("Introduzca el segundo número:");
			num2=Integer.parseInt(teclado.nextLine());
			teclado.close();
			
			if (num1<=num2) {
				vi=num1;
				vf=num2;
			}
			else {
				vi=num2;
				vf=num1;
			}
			for (i = vi; i <= vf; i++) {
				System.out.println(i);
			}
	}

}
