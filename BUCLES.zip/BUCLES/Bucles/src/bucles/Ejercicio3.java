package bucles;

public class Ejercicio3 {

	public static void main(String[] args) {
		/* Diseñar un programa que muestre los 10 primeros números que son 
		 * múltiplos de 3 (hay que hacerlo pensando que no sabemos cuáles 
		 * son los números múltiplos de 3.)
		 * Cuestiones para que pase los test:
		 * 
		 */
		
		// Variables
			int contador, result;
		// Inicio
			result=0;
			contador=0;
			
			while (contador!=10) {
				result++;
				
				if (result%3==0) {
					System.out.println(result);
					contador++;
				}
			}
	}

}
