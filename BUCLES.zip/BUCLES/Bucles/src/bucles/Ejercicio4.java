package bucles;
import java.util.Scanner;

public class Ejercicio4 {

	public static void main(String[] args) {
		/* Diseñar un programa que pida un número entero y nos muestre los 
		 * 10 siguientes números que son múltiplos de 5.
		 * Cuestiones para que pase los test:
		 * Para pedir el número debe mostrar el mensaje exacto 
		 * "Introduzca un número:"
		 * 
		 */
		
		// Variables
			int contador, num;
			Scanner teclado = new Scanner(System.in); 
		// Inicio
			System.out.println("Introduzca un número:");
			num=Integer.parseInt(teclado.nextLine());
			
			contador=0;
			
			while (contador!=10) {
				num++;
				
				if (num%5==0) {
					System.out.println(num);
					contador++;
				}
			}
	}

}
