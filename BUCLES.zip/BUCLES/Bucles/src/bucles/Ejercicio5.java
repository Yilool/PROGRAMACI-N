package bucles;
import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		/* Diseñar un programa que muestre, para cada número introducido por
		 * teclado, si es par, si es positivo y su cuadrado. El proceso se 
		 * repetirá hasta que el número introducido por teclado sea 0.
		 * Cuestiones para que pase los test:
		 * Para pedir cada número debe mostrar el mensaje exacto 
		 * "Introduzca un número:"
		 * Y para cada número debe mostrar.
		 * "Es par" o bien "Es impar"
		 * "Es positivo" o bien "Es negativo"
		 * "Cuadrado xx"
		 * Si es impar, obviamente mostrará impar, y si es negativo mostrará
		 * negatio. El cero se considera par y positivo.
		 * 
		 */
		
		// Variables
			int num, contador, result;
			Scanner teclado = new Scanner(System.in);
		// Inicio
			result=0;
			contador=1;
			
			do {
				System.out.println("Introduzca un número:");
				num=Integer.parseInt(teclado.nextLine());
				
				if (num%2==0) {
					System.out.println("Es par");
				}
				else {
					System.out.println("Es impar");
				}
				if (num>=0) {
					System.out.println("Es positivo");
				}
				else {
					System.out.println("Es negativo");
				}
				System.out.println(num*num);
			} while (num!=0);
			
	}

}
