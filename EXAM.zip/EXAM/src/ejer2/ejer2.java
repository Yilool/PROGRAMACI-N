package ejer2;

import java.util.Scanner;

public class ejer2 {
	private static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		String codigo,categoria;
		
		System.out.println("Introduce el código del producto: ");
		codigo = teclado.nextLine();
		
		System.out.println("Introduce la categoría del producto: ");
		categoria = teclado.nextLine();
		
		if (validCodigo(codigo)==true) {
			System.out.println("El código "+codigo+" es correcto.");
		} else {
			System.out.println("El código "+codigo+" no es correcto.");
		}
		
		if (validCategoria(categoria)==true) {
			System.out.println("La categoría "+categoria+" es correcta.");
		} else {
			System.out.println("La categoría "+categoria+" no es correcta.");
		}
	}
	private static boolean validCodigo (String cod) {
		boolean c=true;
		char caracter;
		int longcod=cod.length();
		
		if (longcod>=5 && longcod<=12) {
			for (int i = 0; i < longcod; i++) {
				caracter=cod.charAt(i);
					if (Character.isDigit(caracter)) {
						c=true;
					} else {
						c=false;
					}
			}
		} else {
			c=false;
		}
		return c;
	}
	private static boolean validCategoria (String cat) {
		boolean c=true;
		String letra="C";
		String vocal="aeiou";
		int longcat=cat.length();
		
		if (cat.startsWith(letra)) {
			if (longcat>=2 && longcat<=5) {
				for (int j = 1; j < longcat; j++) {
					if (vocal.charAt(j)>0) {
						c=true;
					} else {
						c=false;
					}
				}
			} else {
				c=false;
			}
		} else {
			c=false;
		}
		return c;
	}

}
