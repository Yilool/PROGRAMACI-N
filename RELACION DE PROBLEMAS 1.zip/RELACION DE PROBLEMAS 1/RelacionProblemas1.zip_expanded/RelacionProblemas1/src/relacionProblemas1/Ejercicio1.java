package relacionProblemas1;
import java.util.Scanner;

public class Ejercicio1 {

	
	
	public static void main(String[] args) {
		/*Realizar un programa que lea un número entero por teclado e informe de si
		el número es par o impar (el cero se considera par).
		Cuestiones para que pase los test:
		Para pedir el número debe mostrar el mensaje exacto "Introduzca un número:"
		Debe responder "El número es par" o "El número es impar"*/
		
		// Variables
			int numero, resto;
			Scanner teclado = new Scanner(System.in);
			
		//Inicio
			System.out.println("Introduzca un número:");
			numero=Integer.parseInt(teclado.nextLine());
			
			resto = numero%2;
			
			if (resto == 1) {
				System.out.println("El número es impar");
			}
			else {
				System.out.println("El número es par");
			}
			
			
	}

}
