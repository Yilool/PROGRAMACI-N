package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio10 {

	public static void main(String[] args) {
		/*
		 * Realizar un programa que lea un carácter y dos números enteros 
		 * por teclado. Si el carácter leído es un operador aritmético, 
		 * calcular la operación correspondiente, si es cualquier otro debe
		 * mostrar un error.
		 *  Cuestiones para que pase los test:
		 *  Para solicitar el primer número se debe escribir "Introduzca el primer número:"
		 *  Para solicitar el segundo número se debe escribir "Introduzca el segundo número:"
		 *  Para soicitar el operador se debe escribir "Introduzca el operador:"
		 *  Si el operador no es el adecuado (+ - / * ) debe decir "Operador no permitido"
		 *  El resultado debe aparecer de la forma "num1 operador num2 = resultado"
		 */
		
		// Variables
	
		
		// Inicio
		
	}

}
