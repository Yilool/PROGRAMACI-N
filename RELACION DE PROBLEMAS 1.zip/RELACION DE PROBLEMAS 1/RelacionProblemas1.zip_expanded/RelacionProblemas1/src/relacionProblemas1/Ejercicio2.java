package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio2 {
	public static void main(String[] args) {
		//Realizar un programa que solicite dos números por teclado e imprima en
		//pantalla si son iguales, el primero mayor que el segundo o el primero más 
		//pequeño que el segundo.
		//Cuestiones para que pase los test:
		//Para pedir el número debe mostrar el mensaje exacto "Introduzca un número:"
		//Para pedie el segundo número debe mostrar el mensaje exacto "Introduzca otro número:"
		// Debe mostrar los siguientes mensajes según el caso:
		//"El primer número es mayor que el segundo"
		//"El primer número es más pequeño que el segundo"
		//"Los dos números son iguales"
		
		// Variables
			int num1, num2;
			Scanner teclado = new Scanner(System.in);
		//Inicio
			System.out.println("Introduzca un número:");
			num1=Integer.parseInt(teclado.nextLine());
			
			System.out.println("Introduzca otro número:");
			num2=Integer.parseInt(teclado.nextLine());
			
			if (num1-num2==0) {
				System.out.println("Los dos números son iguales");
			}
			else {
				if (num1>num2) {
					System.out.println("El primer número es mayor que el segundo");
				}
				else {
					System.out.println("El primer número es más pequeño que el segundo");
				}
			}
	}

}
