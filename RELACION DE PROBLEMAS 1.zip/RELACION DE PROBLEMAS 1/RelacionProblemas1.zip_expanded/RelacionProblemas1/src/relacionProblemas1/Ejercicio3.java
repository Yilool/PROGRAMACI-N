package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio3 {
	// Constantes
		

	public static void main(String[] args) {
		//Realizar un programa que lea un número por teclado. El programa debe
		//imprimir en pantalla un mensaje con “El número xx es múltiplo de 2” o un
		//mensaje con “El número xx es múltiplo de 3”. Si es múltiplo de 2 y de 3
		//deben aparecer los dos mensajes. Si no es múltiplo de ninguno de los dos
		//el programa finaliza sin mostrar ningún mensaje.
		//Cuestiones para que pase los test:
		// En el caso de que muestre los dos mensajes, debe mostrar primero que es múltiplo de 2 y luego de 3
		// El número se debe pedir con el mensaje "Introduzca un número:"

		
		// Variables
			int num1;
			Scanner teclado = new Scanner(System.in);
		//Inicio
			System.out.println("Introduzca un número:");
			num1=Integer.parseInt(teclado.nextLine());
			
			if (num1%2==0) {
				System.out.println("El número "+num1+" es múltiplo de 2");
			}
			if (num1%3==0) {
				System.out.println("El número "+num1+" es múltiplo de 3");
			}
	}

}
