package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio4 {
	// Constantes
		
		
		

	public static void main(String[] args) {
		//Realizar un programa que lea la edad de una persona menor a 100 años e
		//informe de si es un niño (0-12 años), un adolescente (13-17), un joven (18-
		//29) o un adulto.
		//Cuestiones para que pase los test:
		//Se solicita la edad con el mensaje "Introduzca la edad de la persona:"
		//Y responde con los mensajes siguientes según el caso:
		//"Es un niño"
		//"Es un adolescente"
		//"Es un joven"
		//"Es un adulto"
		//NOTA: se supone que la edad es correcta, es decir es un entero entre 0 y 99

		
		// Variables
			int edad;
			Scanner teclado = new Scanner(System.in);
		//Inicio
			System.out.println("Introduzca la edad de la persona:");
			edad=Integer.parseInt(teclado.nextLine());
			if (edad<=100) {
				if (edad>12) {
					if (edad>17) {
						if (edad>29) {
							System.out.println("Es un adulto");
						}
						else {
							System.out.println("Es un joven");
						}
					}
					else {
						System.out.println("Es un adolescente");
					}
				}
				else {
					System.out.println("Es un niño");
				}
			}
	}

}
