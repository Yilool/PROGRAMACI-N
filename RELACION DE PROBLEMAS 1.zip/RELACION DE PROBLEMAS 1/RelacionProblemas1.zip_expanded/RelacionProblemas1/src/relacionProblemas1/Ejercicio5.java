package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
		//Realizar un programa que solicite 4 números e imprima la media de los
		//números. También debe imprimir aquellos números que son superiores a la
		//media
		//Cuestiones para que pase los test:
		//Solicitará cuatro números con el mismo mensaje: "Introduzca un número:"
		//Devolverá la media con el siguiente mensaje: "La media es: 7.25"
		//Devolverá los números que superen la media uno por línea, por ejemplo:
		//Si introducimos 6, 6, 7, 7 devolvería:
		//La media es: 6.5
		//7
		//7
		
		// Variables
			int num1, num2, num3, num4;
			double media;
			Scanner teclado = new Scanner(System.in);	
		//Inicio
			System.out.println("Introduzca un número:");
			num1=Integer.parseInt(teclado.nextLine());
			
			System.out.println("Introduzca un número:");
			num2=Integer.parseInt(teclado.nextLine());
			
			System.out.println("Introduzca un número:");
			num3=Integer.parseInt(teclado.nextLine());
			
			System.out.println("Introduzca un número:");
			num4=Integer.parseInt(teclado.nextLine());
			
			teclado.close();
			media = (num1+num2+num3+num4)/4.0;
			System.out.println("La media es: "+media);
			
			if (num1>media) {
				System.out.println(num1);
			}
			
			if (num2>media) {
				System.out.println(num2);
			}
			
			if (num3>media) {
				System.out.println(num3);
			}
			
			if (num4>media) {
				System.out.println(num4);
			}
	}

}
