package relacionProblemas1;

import java.util.Scanner;


public class Ejercicio6 {

	public static void main(String[] args) {
		//Realizar un programa que solicite un carácter por teclado e informe por
		//pantalla si el carácter es una vocal o no lo es. Si es una vocal mostrará el
		//mensaje “Es la primera vocal (A)” o “Es la segunda vocal (E)”, etc.
		//Cuestiones para que pasen los test:
		//Se solicita el carácter con el mensaje: "Introduzca un carácter:"
		//Si es vocal muestra:
		//"El carácter introducido es una vocal"
		//"Es la primera vocal (A)"    Obviamente según la vocal mostrará el mensaje
		//Si no es vocal muestra:
		//"El carácter introducido no es una vocal"
		
		// Variables
			char letra;
			Scanner teclado = new Scanner(System.in);
		// Inicio
			System.out.println("Introduzca un carácter:");
			letra=teclado.nextLine().charAt(0);
			
			switch (letra) 
			{
				case 'a':
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la primera vocal (A)");
					break;
				}
				case 'e': 
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la segunda vocal (E)");
					break;
				}
				case 'i': 
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la tercera vocal (I)");
					break;
				}
				case 'o': 
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la cuarta vocal (O)");
					break;
				}
				case 'u': 
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la quinta vocal (U)");
					break;
				}
				case 'A':
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la primera vocal (A)");
					break;
				}
				case 'E': 
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la segunda vocal (E)");
					break;
				}
				case 'I': 
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la tercera vocal (I)");
					break;
				}
				case 'O': 
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la cuarta vocal (O)");
					break;
				}
				case 'U': 
				{
					System.out.println("El carácter introducido es una vocal");
					System.out.println("Es la quinta vocal (U)");
					break;
				}
				default:
				{	
					System.out.println("El carácter introducido no es una vocal");
				}
			}
	}
}

