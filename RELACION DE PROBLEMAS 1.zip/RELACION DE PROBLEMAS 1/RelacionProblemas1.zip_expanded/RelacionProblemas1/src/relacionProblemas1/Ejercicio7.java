package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio7 {
			//Constante
	public static void main(String[] args) {
		/*
		 * Realizar un programa que lea el estado civil de una persona (S-Soltero, C-
		 * Casado, V-Viudo y D-Divorciado) y su edad. Después debe mostrar por pantalla
		 * el porcentaje de retención que debe aplicársele de acuerdo con las siguientes
		 * reglas: 
		 		* A los solteros o divorciados menores de 35 años, un 12% 
		 		* Todas las personas mayores de 50 años, un 8.5% 
		 		* A los viudos o casados menores de 35 años, un 11.3% 
		 		* Al resto de casos se le aplica un 10.5%
		 * Cuestiones para que pasen los test:
		 * Se solicita el carácter con el mensaje: "Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):"
		 * Se solicita la edad con el mensaje: "Introduzca la edad (0-100):"
		 * Según sea el caso:
		 * "El porcentaje a aplicar es: 8.5%"
		 * Obviamente según el caso mostrará el número correspondiente
		 * Primero debe comprobar si la edad está comprendida entre 0 y 100. Si no lo cumple, debe mostrar el mensaje:
		 * "La edad introducida no es válida"
		 * Luego comprobará si el estado civil no es válido, en cuyo caso debe mostrar el mensaje
		 * "Estado civil incorrecto"
		 */
		
		// Variables
			char estCivil;
			double porcent;
			int edad;
			Scanner teclado = new Scanner(System.in);
		// Inicio
			System.out.println("Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):");
			estCivil=teclado.nextLine().charAt(0);
			
			//estCivil = Character.toUpperCase(estCivil);
			
			
			System.out.println("Introduzca la edad (0-100):");
			edad=Integer.parseInt(teclado.nextLine());
			
			if (edad>0 && edad<=100) {
				if (estCivil=='S' || estCivil=='C'|| estCivil=='V' || estCivil=='D') {
					if (edad>50) {
						porcent=8.5;
					}
					else {
						if (edad<35) {
							if (estCivil=='S' || estCivil=='D') {
								porcent=12;
							}
							else {
								porcent=11.3;
							}
						}
						else {
							porcent=10.5;
						}
					}
				System.out.println("El porcentaje a aplicar es: "+porcent+"%");
				}
				else {
					System.out.println("Estado civil incorrecto");
				}
			}
			else {
				System.out.println("La edad introducida no es válida");
			}
	}
}
			
				