package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio8 {
	// Constantes
	

	public static void main(String[] args) {
		/*
		 * Realizar un programa que lea por teclado dos marcaciones de un reloj
		 * digital (horas, minutos, segundos) comprendidas entre las 0:0:0 y las
		 * 23:59:59 e informe cual de ellas es mayor.
		 * Cuestiones para que pase los test:
		 * Para solicitar la primera fecha debe decir ""Introduce la primera marcación (hora INTRO minutos INTRO segundos INTRO):"
		 * Si la fecha no es adecuada escribir "Hora no correcta" y terminar.
		 * Para solicitar la segunda fecha debe decir ""Introduce la segunda marcación (hora INTRO minutos INTRO segundos INTRO):"
		 * Si la fecha no es adecuada escribir "Hora no correcta" y terminar.
		 * La salida debe ser
		 * "Hora 1 es mayor que Hora 2"
		 * "Hora 2 es mayor que Hora 1"
		 * "Hora 1 es igual que Hora 2"

		 */

		
		// Variables
		
		
		// Inicio
	}

}
