package relacionProblemas1;

import java.util.Scanner;

public class Ejercicio9 {
	// Constantes


	public static void main(String[] args) {
		/*
		 * En un establecimiento en rebajas, hay 3 tipos de productos (A, B y C). 
		 * El porcentaje de rebaja que se aplicará sobre el precio original del
		 * producto se calcula de la siguiente forma:
		 		* Si el producto es de tipo A, independientemente de su precio se aplica un 7% de descuento.
		 		* Si el producto es de tipo C o bien el precio es inferior a 500€ se aplicará un porcentaje del 12% de descuento.
		 		* En el resto de casos se aplica un 9% de descuento.
		 * Realizar un programa que solicite los datos necesarios 
		 * (tipo de producto y precio original) y calcule el precio rebajado.
		 * Debe comprobarse que los datos de entrada son correctos, y si no lo 
		 * son mostrar un mensaje de error.
		 * Cuestiones para que pase los test:
		 * Para pedir el tipo del producto se deberá escribir "Introduzca el tipo de producto (A, B, C):"
		 * Si el tipo de producto no es correcto deberá decir "Producto no válido"
		 * Para solicitar el precio se deberá realizar con el mensaje "Introduzca el precio original:"
		 * Si el precio es menor que cero deberá aparecer el mensaje "Precio no válido"
		 * Para decir el precio rebajado debe decir "El precio original era xx y el rebajado es yy"
		 * 
		 */
		
		// Variables 
			char tipProducto;
			double precio, coste;
			Scanner teclado = new Scanner(System.in);
		// Inicio del programa
			System.out.println("Introduzca el tipo de producto (A, B, C):");
			tipProducto=teclado.nextLine().charAt(0);
			
			if (tipProducto=='A' || tipProducto=='B' || tipProducto=='C') {
				
			}
			else {
				System.out.println("Producto no válido");
			}
			
			
	}

}
