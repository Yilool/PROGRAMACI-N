package relacionProblemas1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class Ejercicio10Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String num1, String num2,String operador,String respuesta) {
		String parametro = num1+"\n"+num2+"\n"+operador;
		ByteArrayInputStream in = new ByteArrayInputStream(parametro.getBytes());
		System.setIn(in);
		Ejercicio10.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("3","4","+","Introduzca el primer número:\nIntroduzca el segundo número:\nIntroduzca el operador:\n3 + 4 = 7\n"),
				Arguments.of("3","4","-","Introduzca el primer número:\nIntroduzca el segundo número:\nIntroduzca el operador:\n3 - 4 = -1\n"),
				Arguments.of("3","4","*","Introduzca el primer número:\nIntroduzca el segundo número:\nIntroduzca el operador:\n3 * 4 = 12\n"),
				Arguments.of("3","4","/","Introduzca el primer número:\nIntroduzca el segundo número:\nIntroduzca el operador:\n3 / 4 = 0\n"),
				Arguments.of("3","4","$","Introduzca el primer número:\nIntroduzca el segundo número:\nIntroduzca el operador:\nOperador no permitido\n")
				);
	}
}