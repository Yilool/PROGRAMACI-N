package relacionProblemas1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class Ejercicio5Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String numero1, String numero2, String numero3, String numero4, String respuesta) {
		String numero = numero1+"\n"+numero2+"\n"+numero3+"\n"+numero4;
		ByteArrayInputStream in = new ByteArrayInputStream(numero.getBytes());
		System.setIn(in);
		Ejercicio5.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("4","4","4","5","Introduzca un número:\nIntroduzca un número:\nIntroduzca un número:\nIntroduzca un número:\nLa media es: 4.25\n5\n"),
				Arguments.of("4","4","4","4","Introduzca un número:\nIntroduzca un número:\nIntroduzca un número:\nIntroduzca un número:\nLa media es: 4.0\n"),
				Arguments.of("6","6","7","7","Introduzca un número:\nIntroduzca un número:\nIntroduzca un número:\nIntroduzca un número:\nLa media es: 6.5\n7\n7\n"));
	}
}
