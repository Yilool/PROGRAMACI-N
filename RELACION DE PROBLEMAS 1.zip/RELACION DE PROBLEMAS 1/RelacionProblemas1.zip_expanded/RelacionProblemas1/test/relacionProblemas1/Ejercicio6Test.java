package relacionProblemas1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class Ejercicio6Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String caracter, String respuesta) {
		ByteArrayInputStream in = new ByteArrayInputStream(caracter.getBytes());
		System.setIn(in);
		Ejercicio6.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("a","Introduzca un carácter:\nEl carácter introducido es una vocal\nEs la primera vocal (A)\n"),
				Arguments.of("E","Introduzca un carácter:\nEl carácter introducido es una vocal\nEs la segunda vocal (E)\n"),
				Arguments.of("i","Introduzca un carácter:\nEl carácter introducido es una vocal\nEs la tercera vocal (I)\n"),
				Arguments.of("O","Introduzca un carácter:\nEl carácter introducido es una vocal\nEs la cuarta vocal (O)\n"),
				Arguments.of("u","Introduzca un carácter:\nEl carácter introducido es una vocal\nEs la quinta vocal (U)\n"),
				Arguments.of("d","Introduzca un carácter:\nEl carácter introducido no es una vocal\n"),
				Arguments.of("*","Introduzca un carácter:\nEl carácter introducido no es una vocal\n"));
	}
}
