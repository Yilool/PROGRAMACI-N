package relacionProblemas1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class Ejercicio7Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String estadoCivil, String edad, String respuesta) {
		String estadoCivilEdad = estadoCivil+"\n"+edad;
		ByteArrayInputStream in = new ByteArrayInputStream(estadoCivilEdad.getBytes());
		System.setIn(in);
		Ejercicio7.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("S","50","Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):\nIntroduzca la edad (0-100):\nEl porcentaje a aplicar es: 10.5%\n"),
				Arguments.of("S","51","Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):\nIntroduzca la edad (0-100):\nEl porcentaje a aplicar es: 8.5%\n"),
				Arguments.of("S","30","Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):\nIntroduzca la edad (0-100):\nEl porcentaje a aplicar es: 12.0%\n"),
				Arguments.of("D","30","Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):\nIntroduzca la edad (0-100):\nEl porcentaje a aplicar es: 12.0%\n"),
				Arguments.of("V","30","Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):\nIntroduzca la edad (0-100):\nEl porcentaje a aplicar es: 11.3%\n"),
				Arguments.of("C","30","Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):\nIntroduzca la edad (0-100):\nEl porcentaje a aplicar es: 11.3%\n"),
				Arguments.of("d","50","Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):\nIntroduzca la edad (0-100):\nEstado civil incorrecto\n"),
				Arguments.of("S","120","Introduzca el estado civil (S-Soltero, C-Casado, V-Viudo, D-Divorciado):\nIntroduzca la edad (0-100):\nLa edad introducida no es válida\n"));
	}
}
