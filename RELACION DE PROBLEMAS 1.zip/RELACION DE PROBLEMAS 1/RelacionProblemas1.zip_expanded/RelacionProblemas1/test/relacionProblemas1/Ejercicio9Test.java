package relacionProblemas1;

import static org.junit.jupiter.api.Assertions.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class Ejercicio9Test {
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
	private final PrintStream originalOut = System.out;
	private final PrintStream originalErr = System.err;

	@BeforeEach
	public void setUpStreams() {
	    System.setOut(new PrintStream(outContent));
	    System.setErr(new PrintStream(errContent));
	}

	@AfterEach
	public void restoreStreams() {
	    System.setOut(originalOut);
	    System.setErr(originalErr);
	    System.setIn(System.in);
	}
	
	@ParameterizedTest
	@MethodSource("parametros")
	void withMethodSource(String tipo, String precio,String respuesta) {
		String parametro = tipo+"\n"+precio;
		ByteArrayInputStream in = new ByteArrayInputStream(parametro.getBytes());
		System.setIn(in);
		Ejercicio9.main(null);
		assertEquals(respuesta,outContent.toString());
	}
	
	private static Stream<Arguments> parametros() {
		return Stream.of(
				Arguments.of("A","10","Introduzca el tipo de producto (A, B, C):\nIntroduzca el precio original:\nEl precio original era 10.0 y el rebajado es 9.3\n"),
				Arguments.of("C","10","Introduzca el tipo de producto (A, B, C):\nIntroduzca el precio original:\nEl precio original era 10.0 y el rebajado es 8.8\n"),
				Arguments.of("C","540","Introduzca el tipo de producto (A, B, C):\nIntroduzca el precio original:\nEl precio original era 540.0 y el rebajado es 475.2\n"),
				Arguments.of("B","540","Introduzca el tipo de producto (A, B, C):\nIntroduzca el precio original:\nEl precio original era 540.0 y el rebajado es 491.4\n"),
				Arguments.of("B","500","Introduzca el tipo de producto (A, B, C):\nIntroduzca el precio original:\nEl precio original era 500.0 y el rebajado es 455.0\n"),
				Arguments.of("B","490","Introduzca el tipo de producto (A, B, C):\nIntroduzca el precio original:\nEl precio original era 490.0 y el rebajado es 431.2\n"),
				Arguments.of("f","10","Introduzca el tipo de producto (A, B, C):\nProducto no válido\n"),
				Arguments.of("A","-10","Introduzca el tipo de producto (A, B, C):\nIntroduzca el precio original:\nPrecio no válido\n"));
	}
}
